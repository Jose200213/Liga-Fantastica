#ifndef _REGISTRO_H_
#define _REGISTRO_H_

#include "tipos.h"

void registro(usuario **,int *);//Ojo doble puntero para usuario ya que usamos uno para llegar a usuarios, y luego//
//y luego otro para acceder (ya que cuando se registra pasa a ser un usuario más que accede como los demás//

#endif
